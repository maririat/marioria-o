import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-r-iesgoportapas',
  templateUrl: 'r-iesgoportapas.html'
})
export class RIESGOPORTAPASPage {

  constructor(public navCtrl: NavController) {
  }
  
}
