import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-r-iesgoporarboles',
  templateUrl: 'r-iesgoporarboles.html'
})
export class RIESGOPORARBOLESPage {

  constructor(public navCtrl: NavController) {
  }
  
}
