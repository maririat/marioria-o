import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-r-iesgoelectrico',
  templateUrl: 'r-iesgoelectrico.html'
})
export class RIESGOELECTRICOPage {

  constructor(public navCtrl: NavController) {
  }
  
}
